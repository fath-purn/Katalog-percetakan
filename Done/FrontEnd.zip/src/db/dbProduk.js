import produk1 from '../img/produk1.png';
import produk2 from '../img/produk2.png';
import produk3 from '../img/produk3.png';
import produk4 from '../img/produk4.png';
import produk5 from '../img/produk5.png';

const dbProduk = [
  {
    id: 1,
    namaProduk:"Kemasan Makanan",
    media: produk1,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 2,
    namaProduk:"Kemasan Makanan",
    media: produk2,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 3,
    namaProduk:"Kemasan Makanan",
    media: produk3,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 4,
    namaProduk:"Kemasan Makanan",
    media: produk4,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 5,
    namaProduk:"Kemasan Makanan",
    media: produk5,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 6,
    namaProduk:"Kemasan Makanan",
    media: produk1,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 7,
    namaProduk:"Kemasan Makanan",
    media: produk2,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 8,
    namaProduk:"Kemasan Makanan",
    media: produk3,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 9,
    namaProduk:"Kemasan Makanan",
    media: produk4,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 10,
    namaProduk:"Kemasan Makanan",
    media: produk5,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 11,
    namaProduk:"Kemasan Makanan",
    media: produk1,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 12,
    namaProduk:"Kemasan Makanan",
    media: produk2,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 13,
    namaProduk:"Kemasan Makanan",
    media: produk3,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 14,
    namaProduk:"Kemasan Makanan",
    media: produk4,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 15,
    namaProduk:"Kemasan Makanan",
    media: produk5,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 16,
    namaProduk:"Kemasan Makanan",
    media: produk1,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 17,
    namaProduk:"Kemasan Makanan",
    media: produk2,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 18,
    namaProduk:"Kemasan Makanan",
    media: produk3,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 19,
    namaProduk:"Kemasan Makanan",
    media: produk4,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
  {
    id: 20,
    namaProduk:"Kemasan Makanan",
    media: produk5,
    deskripsi:"Kemasan menggunakan kertas dan tinta yang premium",
    harga:"1000",
    kategori:"#kemasan #bebasDesain",
    ulasan:"Bagus cekali"
  },
]

export default dbProduk;