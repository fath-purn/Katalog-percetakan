const dbFAQ = [
    {
        id:1,
        FAQJudul:"Anim pariatur cliche reprehenderit?",
        FAQDeskripsi: "Anim pariatur cliche reprehenderit, enim eiusmod high lifeaccusamus terry richardson ad squid. 3 wolf moon officia aute,non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft bee farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS."
    },
    {
        id:2,
        FAQJudul:"Consectetur adipiscing elit",
        FAQDeskripsi: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Semper eget duis at tellus at urna. Quis risus sed vulputate odio ut enim blandit volutpat. Volutpat ac tincidunt vitae semper quis lectus. Elit eget gravida cum sociis natoque penatibus et magnis dis. Aliquet porttitor lacus luctus accumsan tortor posuere. Convallis a cras semper auctor neque vitae tempus quam. Praesent elementum facilisis leo vel fringilla. Non quam lacus suspendisse faucibus interdum posuere. Augue eget arcu dictum varius duis at consectetur lorem donec. Amet est placerat in egestas erat imperdiet sed euismod nisi. Odio euismod lacinia at quis risus. Vitae auctor eu augue ut. Nulla porttitor massa id neque. Vel pharetra vel turpis nunc."
    },
    {
        id:3,
        FAQJudul:"Sit amet porttitor eget dolor morbi non arcu",
        FAQDeskripsi: "In hac habitasse platea dictumst. Donec massa sapien faucibus et molestie ac feugiat sed. In hendrerit gravida rutrum quisque. Tellus molestie nunc non blandit massa enim nec dui. Nunc non blandit massa enim nec dui nunc mattis. Nisl vel pretium lectus quam. Sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit. Commodo nulla facilisi nullam vehicula ipsum a arcu. Ornare arcu dui vivamus arcu felis bibendum. Habitasse platea dictumst quisque sagittis purus sit amet volutpat. Dignissim suspendisse in est ante in nibh. Sit amet porttitor eget dolor morbi non arcu risus."
    },
    {
        id:4,
        FAQJudul:"Pretium vulputate sapien nec sagittis",
        FAQDeskripsi: "Adipiscing elit ut aliquam purus sit amet luctus venenatis lectus. Varius vel pharetra vel turpis nunc eget lorem dolor sed. Lobortis elementum nibh tellus molestie nunc non blandit massa enim. Molestie a iaculis at erat pellentesque adipiscing commodo. Egestas integer eget aliquet nibh. Nulla pharetra diam sit amet nisl. Sed euismod nisi porta lorem. Sed elementum tempus egestas sed sed risus pretium quam vulputate. Lectus nulla at volutpat diam. Nascetur ridiculus mus mauris vitae. Fermentum dui faucibus in ornare quam viverra orci. Sagittis vitae et leo duis. Sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit. Eget lorem dolor sed viverra ipsum nunc aliquet bibendum enim. Diam maecenas ultricies mi eget mauris pharetra. Eu turpis egestas pretium aenean pharetra magna. Nisi porta lorem mollis aliquam ut porttitor. Ut morbi tincidunt augue interdum velit euismod in pellentesque. Sodales neque sodales ut etiam sit. Pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu vitae."
    },
    {
        id:5,
        FAQJudul:"Nibh praesent tristique magna sit amet purus",
        FAQDeskripsi: "Cras sed felis eget velit aliquet sagittis id consectetur. Convallis posuere morbi leo urna molestie at elementum. A iaculis at erat pellentesque adipiscing commodo. Magna ac placerat vestibulum lectus mauris ultrices eros in. Dolor magna eget est lorem. Eget mi proin sed libero enim sed faucibus turpis in. Porttitor eget dolor morbi non arcu risus quis varius quam. Sed nisi lacus sed viverra tellus in hac. Tempor nec feugiat nisl pretium fusce id velit. Ac turpis egestas maecenas pharetra convallis posuere morbi. Dictum sit amet justo donec enim. At risus viverra adipiscing at in tellus. Ultrices sagittis orci a scelerisque purus semper. Vulputate dignissim suspendisse in est ante in. Nibh praesent tristique magna sit amet purus."
    },
    {
        id:6,
        FAQJudul:"Nisl tincidunt eget nullam non",
        FAQDeskripsi: "Nisi quis eleifend quam adipiscing vitae proin. Nisl tincidunt eget nullam non nisi est sit amet facilisis. Consectetur adipiscing elit pellentesque habitant morbi tristique senectus et netus. Eu scelerisque felis imperdiet proin fermentum leo. "
    },

]

export default dbFAQ;