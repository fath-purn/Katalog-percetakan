const firebaseConfig = {
    apiKey: "AIzaSyCVio_sA3K8BUdTmcFXHWKyaB9OHPWxRiQ",
    authDomain: "javaindo-percetakan.firebaseapp.com",
    projectId: "javaindo-percetakan",
    storageBucket: "javaindo-percetakan.appspot.com",
    messagingSenderId: "503397054055",
    appId: "1:503397054055:web:72326cc463b662c81006c2",
    measurementId: "G-1L1212J8JC"
};
  
// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);